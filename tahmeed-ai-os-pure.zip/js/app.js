const API_BASE = 'api.php?action=';

document.addEventListener('DOMContentLoaded', () => {
    initNavigation();
    loadDashboard();
});

function initNavigation() {
    document.querySelectorAll('.nav-item').forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            navigateToSection(item.getAttribute('data-section'));
        });
    });
}

function navigateToSection(id) {
    document.querySelectorAll('.nav-item').forEach(i => i.classList.remove('active'));
    const nav = document.querySelector(`[data-section="${id}"]`);
    if (nav) nav.classList.add('active');
    document.querySelectorAll('.content-section').forEach(s => s.classList.remove('active'));
    const sec = document.getElementById(`section-${id}`);
    if (sec) sec.classList.add('active');
    switch(id) {
        case 'dashboard': loadDashboard(); break;
        case 'agents': loadAgents(); break;
        case 'tasks': loadTasks(); break;
        case 'memory': loadMemory(); break;
        case 'tools': loadTools(); break;
        case 'ai-settings': loadAISettings(); break;
    }
}

async function executeCommand() {
    const input = document.getElementById('command-input');
    const command = input.value.trim();
    if (!command) return;
    const panel = document.getElementById('command-results');
    panel.innerHTML = '<div class="result-item"><div class="result-content"><span class="loading-spinner"></span> এজেন্টরা কাজ করছে...</div></div>';
    try {
        const res = await fetch(API_BASE + 'command', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({command}) });
        const data = await res.json();
        if (data.success) {
            let html = `<div class="result-item fade-in"><div class="result-content" style="color:var(--success);margin-bottom:12px"><strong>${data.message}</strong><br><small>Agent: ${data.routing?.primaryAgent||''}</small></div></div>`;
            (data.results||[]).forEach(r => {
                if (r.result) {
                    html += `<div class="result-item fade-in"><div class="result-content"><strong>${r.result.icon||'🤖'} ${(r.agent||'').toUpperCase()} Agent</strong><br>${r.result.summary||''}<br>`;
                    if (r.result.recommendations) { html += '<br><strong>💡 সুপারিশ:</strong><br>'; r.result.recommendations.forEach(rec => { html += `→ ${rec}<br>`; }); }
                    if (r.result.aiResponse) { html += `<br><strong>🤖 AI:</strong><br>${r.result.aiResponse}`; }
                    html += `<br><small>⏱️ ${r.result.completionTime||''}</small></div></div>`;
                }
            });
            panel.innerHTML = html;
        } else { panel.innerHTML = `<div class="result-item"><div class="result-content" style="color:var(--danger)">❌ ${data.error||'ব্যর্থ'}</div></div>`; }
        input.value = '';
        loadDashboard();
    } catch(e) { panel.innerHTML = `<div class="result-item"><div class="result-content" style="color:var(--danger)">❌ ${e.message}</div></div>`; }
}

function fillCommand(t) { const i = document.getElementById('command-input'); if(i){i.value=t;i.focus();} }

async function loadDashboard() {
    try {
        const res = await fetch(API_BASE + 'dashboard');
        const d = await res.json();
        setText('stat-agents', Array.isArray(d.agents) ? d.agents.length : 0);
        setText('stat-completed', d.tasks?.completed || 0);
        setText('stat-pending', d.tasks?.pending || 0);
        setText('stat-memory', d.memory?.total || 0);
        const agents = Array.isArray(d.agents) ? d.agents : [];
        const grid = document.getElementById('agents-grid');
        if (grid && agents.length) {
            grid.innerHTML = agents.map(a => `<div class="agent-card fade-in"><div class="agent-card-header"><div class="agent-avatar">${getIcon(a.name)}</div><div class="agent-info"><h4>${a.description||a.name}</h4><div class="agent-status"><span class="status-dot online"></span> প্রস্তুত</div></div></div><div class="agent-capabilities">${(a.capabilities||[]).map(c=>`<span class="capability-tag">${c}</span>`).join('')}</div></div>`).join('');
        }
    } catch(e) { console.error(e); }
}

async function loadAgents() {
    try {
        const res = await fetch(API_BASE + 'agents');
        const agents = await res.json();
        const grid = document.getElementById('agents-list');
        if (grid) grid.innerHTML = agents.map(a => `<div class="agent-card fade-in"><div class="agent-card-header"><div class="agent-avatar">${getIcon(a.name)}</div><div class="agent-info"><h4>${a.description}</h4><div class="agent-status"><span class="status-dot online"></span> প্রস্তুত</div></div></div><div class="agent-capabilities">${(a.capabilities||[]).map(c=>`<span class="capability-tag">${c}</span>`).join('')}</div></div>`).join('');
    } catch(e) {}
}

async function loadTasks() {
    try {
        const res = await fetch(API_BASE + 'tasks');
        const tasks = await res.json();
        const el = document.getElementById('tasks-list');
        if (!tasks.length) { el.innerHTML = '<div class="empty-state"><span class="empty-icon">📋</span><p>কমান্ড দিলে টাস্ক তৈরি হবে</p></div>'; return; }
        el.innerHTML = tasks.map(t => `<div class="task-item fade-in"><div class="task-left"><span class="task-status-icon">✅</span><div><div class="task-title">${t.title||''}</div><div class="task-meta">${t.assigned_agent||''} • ${t.created_at||''}</div></div></div><span class="task-badge completed">সম্পন্ন</span></div>`).join('');
    } catch(e) {}
}

async function loadMemory() {
    try {
        const res = await fetch(API_BASE + 'memory');
        const mems = await res.json();
        const el = document.getElementById('memory-list');
        if (!mems.length) { el.innerHTML = '<div class="empty-state"><span class="empty-icon">💾</span><p>মেমরি খালি</p></div>'; return; }
        el.innerHTML = mems.map(m => `<div class="memory-item fade-in"><h4>${m.type||'মেমরি'}</h4><p>${m.content||''}</p><div class="meta">📅 ${m.created_at||''}</div></div>`).join('');
    } catch(e) {}
}

async function loadTools() {
    try {
        const res = await fetch(API_BASE + 'tools');
        const tools = await res.json();
        document.getElementById('tools-list').innerHTML = tools.map(t => `<div class="tool-card fade-in"><div class="tool-icon">${t.icon||'🔧'}</div><h4>${t.name}</h4><p>${t.description||''}</p></div>`).join('');
    } catch(e) {}
}

async function loadAISettings() {}
async function saveAIConfig() { alert('AI Settings → Dashboard থেকে API Key সেট করুন'); }
async function testAI() { alert('প্রথমে API Key সেভ করুন'); }
async function sendAIChat() { alert('প্রথমে AI কনফিগার করুন'); }

function getIcon(n) { return {coding:'💻',research:'🔬',accounting:'💰',marketing:'📣',security:'🔒',content:'📝',data_analysis:'📊'}[n]||'🤖'; }
function setText(id, v) { const e = document.getElementById(id); if(e) e.textContent = v; }
