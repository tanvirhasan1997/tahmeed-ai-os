<?php
header('Content-Type: application/json; charset=utf-8');
$input = json_decode(file_get_contents('php://input'), true);
$path = $_GET['action'] ?? '';

$agents = [
    ['name'=>'coding','description'=>'👨‍💻 Coding Agent - সফটওয়্যার ডেভেলপমেন্ট','capabilities'=>['কোড লেখা','বাগ ফিক্স','API','ডাটাবেস','ডিপ্লয়'],'status'=>'idle','aiPowered'=>false],
    ['name'=>'research','description'=>'🔍 Research Agent - গবেষণা ও তথ্য সংগ্রহ','capabilities'=>['মার্কেট রিসার্চ','ট্রেন্ড','ডাটা সংগ্রহ'],'status'=>'idle','aiPowered'=>false],
    ['name'=>'accounting','description'=>'🧾 Accounting Agent - আর্থিক হিসাব','capabilities'=>['ইনভয়েস','বাজেট','ট্যাক্স','রিপোর্ট'],'status'=>'idle','aiPowered'=>false],
    ['name'=>'marketing','description'=>'📈 Marketing Agent - মার্কেটিং কৌশল','capabilities'=>['SEO','ক্যাম্পেইন','সোশ্যাল মিডিয়া','ব্র্যান্ডিং'],'status'=>'idle','aiPowered'=>false],
    ['name'=>'security','description'=>'🛡️ Security Agent - সিকিউরিটি অডিট','capabilities'=>['অডিট','ভালনারেবিলিটি','এনক্রিপশন','ব্যাকআপ'],'status'=>'idle','aiPowered'=>false],
    ['name'=>'content','description'=>'📝 Content Agent - কন্টেন্ট তৈরি','capabilities'=>['আর্টিকেল','ব্লগ','রিপোর্ট','কপিরাইটিং'],'status'=>'idle','aiPowered'=>false],
    ['name'=>'data_analysis','description'=>'📊 Data Analysis Agent - ডাটা বিশ্লেষণ','capabilities'=>['চার্ট','KPI','পরিসংখ্যান','ট্রেন্ড'],'status'=>'idle','aiPowered'=>false],
];

$icons = ['coding'=>'💻','research'=>'🔬','accounting'=>'💰','marketing'=>'📣','security'=>'🔒','content'=>'📝','data_analysis'=>'📊'];
$kw_map = ['code'=>'coding','কোড'=>'coding','বানাও'=>'coding','module'=>'coding','মডিউল'=>'coding','upgrade'=>'coding','আপগ্রেড'=>'coding','feature'=>'coding','ফিচার'=>'coding','bug'=>'coding','fix'=>'coding','security'=>'security','সিকিউরিটি'=>'security','অডিট'=>'security','hack'=>'security','marketing'=>'marketing','মার্কেটিং'=>'marketing','ক্যাম্পেইন'=>'marketing','seo'=>'marketing','ads'=>'marketing','হিসাব'=>'accounting','বাজেট'=>'accounting','invoice'=>'accounting','tax'=>'accounting','লেখো'=>'content','রিপোর্ট'=>'content','blog'=>'content','article'=>'content','ডাটা'=>'data_analysis','বিশ্লেষণ'=>'data_analysis','chart'=>'data_analysis','analytics'=>'data_analysis'];

$dataFile = __DIR__ . '/data.json';
if (!file_exists($dataFile)) file_put_contents($dataFile, json_encode(['tasks'=>[],'memories'=>[]]));
$data = json_decode(file_get_contents($dataFile), true);
if (!$data) $data = ['tasks'=>[],'memories'=>[]];

switch ($path) {
    case 'dashboard':
        echo json_encode(['system'=>['name'=>'Tahmeed AI OS','version'=>'1.0.0','status'=>'online'],'agents'=>$agents,'tasks'=>['total'=>count($data['tasks']),'completed'=>count($data['tasks']),'pending'=>0],'memory'=>['total'=>count($data['memories'])]]);
        break;

    case 'agents':
        echo json_encode($agents);
        break;

    case 'command':
        $command = $input['command'] ?? '';
        if (!$command) { echo json_encode(['error'=>'কমান্ড দিন']); break; }
        $agent = 'research';
        foreach ($kw_map as $kw => $ag) { if (mb_stripos($command, $kw) !== false) { $agent = $ag; break; } }
        $task = ['id'=>uniqid(),'title'=>'['.strtoupper($agent).'] '.mb_substr($command,0,100),'assigned_agent'=>$agent,'status'=>'completed','created_at'=>date('Y-m-d H:i:s')];
        $data['tasks'][] = $task;
        $data['memories'][] = ['id'=>uniqid(),'type'=>'conversation','content'=>$command,'created_at'=>date('Y-m-d H:i:s')];
        file_put_contents($dataFile, json_encode($data));
        echo json_encode(['success'=>true,'routing'=>['primaryAgent'=>$agent,'intents'=>[$agent]],'results'=>[['agent'=>$agent,'status'=>'fulfilled','result'=>['agent'=>$agent,'icon'=>$icons[$agent]??'🤖','summary'=>strtoupper($agent).' Agent কাজ সম্পন্ন: '.$command,'recommendations'=>['AI API যোগ করলে বুদ্ধিমান response পাবেন','Dashboard → AI Settings থেকে Gemini key দিন'],'completionTime'=>rand(3,15).' সেকেন্ড']]],'message'=>'✅ কমান্ড সম্পন্ন! 1/1 এজেন্ট সফল।']);
        break;

    case 'tasks':
        echo json_encode(array_reverse($data['tasks']));
        break;

    case 'memory':
        echo json_encode(array_reverse($data['memories']));
        break;

    case 'tools':
        echo json_encode([['name'=>'GitHub','icon'=>'🐙','description'=>'কোড রিপোজিটরি'],['name'=>'VS Code','icon'=>'💻','description'=>'কোড এডিটিং'],['name'=>'Google Drive','icon'=>'📁','description'=>'ফাইল স্টোরেজ'],['name'=>'Gmail','icon'=>'📧','description'=>'ইমেইল'],['name'=>'Slack','icon'=>'💬','description'=>'টিম চ্যাট'],['name'=>'Notion','icon'=>'📓','description'=>'নোটস'],['name'=>'Canva','icon'=>'🎨','description'=>'ডিজাইন'],['name'=>'API','icon'=>'🔌','description'=>'REST API']]);
        break;

    case 'automations':
        echo json_encode([]);
        break;

    case 'ai/status':
        echo json_encode(['configured'=>false,'message'=>'⚠️ AI কনফিগার করা হয়নি']);
        break;

    case 'ai/providers':
        echo json_encode([['id'=>'gemini','name'=>'Gemini (ফ্রি!)','icon'=>'🔵','models'=>['gemini-1.5-flash']],['id'=>'openai','name'=>'OpenAI','icon'=>'🟢','models'=>['gpt-4o-mini']]]);
        break;

    default:
        echo json_encode(['status'=>'ok','message'=>'Tahmeed AI OS API']);
}
