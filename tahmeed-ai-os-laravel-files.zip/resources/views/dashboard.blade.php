<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>Tahmeed AI OS - ড্যাশবোর্ড</title>
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">
</head>
<body>
    <div class="app-container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <span class="logo-icon">🤖</span>
                    <h1>Tahmeed AI OS</h1>
                </div>
                <span class="version-badge">v1.0</span>
            </div>
            <nav class="sidebar-nav">
                <a href="#" class="nav-item active" data-section="dashboard">
                    <span class="nav-icon">📊</span>
                    <span class="nav-label">ড্যাশবোর্ড</span>
                </a>
                <a href="#" class="nav-item" data-section="command-center">
                    <span class="nav-icon">⚡</span>
                    <span class="nav-label">কমান্ড সেন্টার</span>
                </a>
                <a href="#" class="nav-item" data-section="agents">
                    <span class="nav-icon">🧠</span>
                    <span class="nav-label">AI এজেন্ট</span>
                </a>
                <a href="#" class="nav-item" data-section="tasks">
                    <span class="nav-icon">📋</span>
                    <span class="nav-label">টাস্ক</span>
                </a>
                <a href="#" class="nav-item" data-section="memory">
                    <span class="nav-icon">💾</span>
                    <span class="nav-label">মেমরি</span>
                </a>
                <a href="#" class="nav-item" data-section="knowledge">
                    <span class="nav-icon">📚</span>
                    <span class="nav-label">নলেজ</span>
                </a>
                <a href="#" class="nav-item" data-section="automation">
                    <span class="nav-icon">⚙️</span>
                    <span class="nav-label">অটোমেশন</span>
                </a>
                <a href="#" class="nav-item" data-section="tools">
                    <span class="nav-icon">🔧</span>
                    <span class="nav-label">টুলস</span>
                </a>
                <a href="#" class="nav-item" data-section="ai-settings">
                    <span class="nav-icon">🎛️</span>
                    <span class="nav-label">AI সেটিংস</span>
                </a>
            </nav>
            <div class="sidebar-footer">
                <div class="system-status">
                    <span class="status-dot online"></span>
                    <span>সিস্টেম সক্রিয়</span>
                </div>
                <div class="system-time" id="system-time"></div>
            </div>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <!-- Header -->
            <header class="header">
                <div class="header-left">
                    <h2 class="page-title" id="page-title">ড্যাশবোর্ড</h2>
                    <span class="header-subtitle">আপনার AI অপারেটিং সিস্টেম</span>
                </div>
                <div class="header-right">
                    <div class="search-box">
                        <input type="text" placeholder="অনুসন্ধান করুন... (Ctrl+K)" id="global-search">
                    </div>
                    <div class="header-actions">
                        <button class="btn-icon" title="বিজ্ঞপ্তি">🔔</button>
                        <button class="btn-icon" title="সেটিংস">⚙️</button>
                    </div>
                </div>
            </header>

            <!-- Dashboard Section -->
            <section class="content-section active" id="section-dashboard">
                <!-- Stats Grid -->
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-icon">🧠</div>
                        <div class="stat-info">
                            <span class="stat-value" id="stat-agents">0</span>
                            <span class="stat-label">সক্রিয় এজেন্ট</span>
                        </div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon">✅</div>
                        <div class="stat-info">
                            <span class="stat-value" id="stat-completed">0</span>
                            <span class="stat-label">সম্পন্ন টাস্ক</span>
                        </div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon">⏳</div>
                        <div class="stat-info">
                            <span class="stat-value" id="stat-pending">0</span>
                            <span class="stat-label">পেন্ডিং টাস্ক</span>
                        </div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon">💾</div>
                        <div class="stat-info">
                            <span class="stat-value" id="stat-memory">0</span>
                            <span class="stat-label">মেমরি আইটেম</span>
                        </div>
                    </div>
                </div>

                <!-- Agent Cards Grid -->
                <div class="section-header">
                    <h3>AI এজেন্ট সমূহ</h3>
                    <button class="btn-secondary" onclick="loadAgents()">রিফ্রেশ</button>
                </div>
                <div class="agents-grid" id="agents-grid">
                    <!-- Agent cards will be loaded here -->
                </div>

                <!-- Recent Activity -->
                <div class="section-header">
                    <h3>সাম্প্রতিক কার্যক্রম</h3>
                </div>
                <div class="results-panel" id="recent-activity">
                    <div class="empty-state">
                        <span class="empty-icon">📭</span>
                        <p>কোনো সাম্প্রতিক কার্যক্রম নেই</p>
                    </div>
                </div>
            </section>

            <!-- Command Center Section -->
            <section class="content-section" id="section-command-center">
                <div class="command-center">
                    <div class="command-header">
                        <h3>কমান্ড সেন্টার</h3>
                        <p>AI এজেন্টদের নির্দেশ দিন</p>
                    </div>
                    <div class="command-input-wrapper">
                        <input type="text" class="command-input" id="command-input" placeholder="আপনার কমান্ড লিখুন..." onkeypress="if(event.key==='Enter')executeCommand()">
                        <button class="btn-primary" onclick="executeCommand()">পাঠান ➤</button>
                    </div>
                    <div class="command-suggestions">
                        <span class="suggestion-label">সাজেশন:</span>
                        <button class="suggestion-chip" onclick="fillCommand('একটি ব্লগ পোস্ট লিখো')">📝 ব্লগ পোস্ট</button>
                        <button class="suggestion-chip" onclick="fillCommand('মার্কেট রিসার্চ করো')">📊 মার্কেট রিসার্চ</button>
                        <button class="suggestion-chip" onclick="fillCommand('কোড রিভিউ করো')">💻 কোড রিভিউ</button>
                        <button class="suggestion-chip" onclick="fillCommand('সিকিউরিটি অডিট করো')">🔒 সিকিউরিটি অডিট</button>
                        <button class="suggestion-chip" onclick="fillCommand('ডাটা অ্যানালাইসিস করো')">📈 ডাটা অ্যানালাইসিস</button>
                    </div>
                </div>
                <div class="results-panel" id="command-results">
                    <div class="empty-state">
                        <span class="empty-icon">💬</span>
                        <p>কমান্ড এক্সিকিউট করুন ফলাফল দেখতে</p>
                    </div>
                </div>
            </section>

            <!-- Agents Section -->
            <section class="content-section" id="section-agents">
                <div class="section-header">
                    <h3>AI এজেন্ট ম্যানেজমেন্ট</h3>
                    <button class="btn-primary" onclick="loadAgents()">🔄 রিফ্রেশ</button>
                </div>
                <div class="agents-grid" id="agents-list">
                    <!-- Agent cards loaded dynamically -->
                </div>
            </section>

            <!-- Tasks Section -->
            <section class="content-section" id="section-tasks">
                <div class="section-header">
                    <h3>টাস্ক ম্যানেজমেন্ট</h3>
                    <button class="btn-primary" onclick="loadTasks()">🔄 রিফ্রেশ</button>
                </div>
                <div class="tasks-list" id="tasks-list">
                    <div class="empty-state">
                        <span class="empty-icon">📋</span>
                        <p>কোনো টাস্ক নেই</p>
                    </div>
                </div>
            </section>

            <!-- Memory Section -->
            <section class="content-section" id="section-memory">
                <div class="section-header">
                    <h3>মেমরি সিস্টেম</h3>
                    <button class="btn-primary" onclick="loadMemory()">🔄 রিফ্রেশ</button>
                </div>
                <div class="memory-list" id="memory-list">
                    <div class="empty-state">
                        <span class="empty-icon">💾</span>
                        <p>মেমরি খালি</p>
                    </div>
                </div>
            </section>

            <!-- Knowledge Section -->
            <section class="content-section" id="section-knowledge">
                <div class="section-header">
                    <h3>নলেজ ভল্ট</h3>
                    <button class="btn-primary" onclick="loadKnowledge()">🔄 রিফ্রেশ</button>
                </div>
                <div class="knowledge-list" id="knowledge-list">
                    <div class="empty-state">
                        <span class="empty-icon">📚</span>
                        <p>নলেজ ভল্ট খালি</p>
                    </div>
                </div>
            </section>

            <!-- Automation Section -->
            <section class="content-section" id="section-automation">
                <div class="section-header">
                    <h3>অটোমেশন ইঞ্জিন</h3>
                    <button class="btn-primary" onclick="loadAutomations()">🔄 রিফ্রেশ</button>
                </div>
                <div class="automation-list" id="automation-list">
                    <div class="empty-state">
                        <span class="empty-icon">⚙️</span>
                        <p>কোনো অটোমেশন সেটআপ হয়নি</p>
                    </div>
                </div>
            </section>

            <!-- Tools Section -->
            <section class="content-section" id="section-tools">
                <div class="section-header">
                    <h3>টুল হাব</h3>
                    <button class="btn-primary" onclick="loadTools()">🔄 রিফ্রেশ</button>
                </div>
                <div class="tools-grid" id="tools-list">
                    <div class="empty-state">
                        <span class="empty-icon">🔧</span>
                        <p>টুলস লোড হচ্ছে...</p>
                    </div>
                </div>
            </section>

            <!-- AI Settings Section -->
            <section class="content-section" id="section-ai-settings">
                <div class="section-header">
                    <h3>AI সেটিংস</h3>
                </div>

                <!-- Provider Cards -->
                <div class="providers-grid">
                    <div class="provider-card" data-provider="openai">
                        <div class="provider-icon">🟢</div>
                        <h4>OpenAI</h4>
                        <p>GPT-4, GPT-3.5 Turbo</p>
                        <span class="provider-status" id="status-openai">কনফিগার করা হয়নি</span>
                    </div>
                    <div class="provider-card" data-provider="gemini">
                        <div class="provider-icon">🔵</div>
                        <h4>Gemini</h4>
                        <p>Gemini Pro, Gemini Ultra</p>
                        <span class="provider-status" id="status-gemini">কনফিগার করা হয়নি</span>
                    </div>
                    <div class="provider-card" data-provider="claude">
                        <div class="provider-icon">🟣</div>
                        <h4>Claude</h4>
                        <p>Claude 3 Opus, Sonnet</p>
                        <span class="provider-status" id="status-claude">কনফিগার করা হয়নি</span>
                    </div>
                </div>

                <!-- API Key Configuration -->
                <div class="settings-form">
                    <h4>API কনফিগারেশন</h4>
                    <div class="form-group">
                        <label for="ai-provider-select">প্রোভাইডার নির্বাচন করুন</label>
                        <select id="ai-provider-select" class="form-input">
                            <option value="openai">OpenAI</option>
                            <option value="gemini">Gemini</option>
                            <option value="claude">Claude</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="ai-api-key">API Key</label>
                        <input type="password" id="ai-api-key" class="form-input" placeholder="আপনার API key দিন...">
                    </div>
                    <div class="form-group">
                        <label for="ai-model-select">মডেল</label>
                        <select id="ai-model-select" class="form-input">
                            <option value="gpt-4o">GPT-4o</option>
                            <option value="gpt-4o-mini">GPT-4o Mini</option>
                            <option value="gpt-3.5-turbo">GPT-3.5 Turbo</option>
                            <option value="gemini-1.5-pro">Gemini 1.5 Pro</option>
                            <option value="gemini-1.5-flash">Gemini 1.5 Flash</option>
                            <option value="claude-sonnet-4-20250514">Claude Sonnet</option>
                            <option value="claude-3-opus-20240229">Claude 3 Opus</option>
                        </select>
                    </div>
                    <button class="btn-primary" onclick="saveAIConfig()">💾 সংরক্ষণ করুন</button>
                </div>

                <!-- Test Chat -->
                <div class="test-chat-section">
                    <h4>AI টেস্ট চ্যাট</h4>
                    <div class="chat-messages" id="ai-chat-messages">
                        <div class="chat-message system">
                            <p>AI সংযোগ পরীক্ষা করতে একটি মেসেজ পাঠান</p>
                        </div>
                    </div>
                    <div class="chat-input-wrapper">
                        <input type="text" id="ai-chat-input" class="form-input" placeholder="মেসেজ লিখুন..." onkeypress="if(event.key==='Enter')sendAIChat()">
                        <button class="btn-primary" onclick="testAI()">🧪 টেস্ট</button>
                        <button class="btn-secondary" onclick="sendAIChat()">পাঠান</button>
                    </div>
                </div>
            </section>
        </main>
    </div>

    <script src="{{ asset('js/app.js') }}"></script>
</body>
</html>
