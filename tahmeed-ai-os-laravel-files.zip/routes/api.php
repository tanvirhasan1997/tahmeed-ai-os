<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ApiController;

/*
|--------------------------------------------------------------------------
| API Routes - Tahmeed AI OS
|--------------------------------------------------------------------------
|
| All API endpoints for the Tahmeed AI OS application.
|
*/

// Dashboard
Route::get('/dashboard', [ApiController::class, 'dashboard']);

// Command Center
Route::post('/command', [ApiController::class, 'executeCommand']);
Route::get('/commands/history', [ApiController::class, 'commandHistory']);

// Agents
Route::get('/agents', [ApiController::class, 'getAgents']);
Route::get('/agents/stats', [ApiController::class, 'getAgentStats']);

// Tasks
Route::get('/tasks', [ApiController::class, 'getTasks']);
Route::get('/tasks/summary', [ApiController::class, 'getTasksSummary']);

// Memory
Route::get('/memory', [ApiController::class, 'getMemory']);
Route::post('/memory', [ApiController::class, 'storeMemory']);
Route::get('/memory/search', [ApiController::class, 'searchMemory']);
Route::get('/memory/stats', [ApiController::class, 'getMemoryStats']);
Route::delete('/memory/{id}', [ApiController::class, 'deleteMemory']);

// Knowledge
Route::get('/knowledge', [ApiController::class, 'getKnowledge']);
Route::post('/knowledge', [ApiController::class, 'storeKnowledge']);
Route::get('/knowledge/search', [ApiController::class, 'searchKnowledge']);
Route::delete('/knowledge/{id}', [ApiController::class, 'deleteKnowledge']);

// Automations
Route::get('/automations', [ApiController::class, 'getAutomations']);
Route::put('/automations/{id}/toggle', [ApiController::class, 'toggleAutomation']);
Route::get('/automations/status', [ApiController::class, 'getAutomationStatus']);

// Tools
Route::get('/tools', [ApiController::class, 'getTools']);
Route::post('/tools/connect', [ApiController::class, 'connectTool']);
Route::get('/tools/connections', [ApiController::class, 'getToolConnections']);

// AI Routes
Route::get('/ai/status', [ApiController::class, 'aiStatus']);
Route::get('/ai/providers', [ApiController::class, 'aiProviders']);
Route::post('/ai/configure', [ApiController::class, 'aiConfigure']);
Route::delete('/ai/configure', [ApiController::class, 'aiDisable']);
Route::post('/ai/test', [ApiController::class, 'aiTest']);
Route::post('/ai/chat', [ApiController::class, 'aiChat']);
Route::get('/ai/usage', [ApiController::class, 'aiUsage']);
