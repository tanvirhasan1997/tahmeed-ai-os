<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     * Creates all tables for Tahmeed AI OS
     */
    public function up(): void
    {
        // Memory table - stores conversations and context
        Schema::create('memory', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('type'); // conversation, context, fact, preference
            $table->text('content');
            $table->text('context')->nullable();
            $table->json('tags')->nullable();
            $table->string('importance')->default('medium'); // low, medium, high
            $table->timestamps();
        });

        // Knowledge vault - stores documents and knowledge items
        Schema::create('knowledge', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('title');
            $table->string('type'); // document, note, reference, tutorial
            $table->longText('content')->nullable();
            $table->json('metadata')->nullable();
            $table->json('tags')->nullable();
            $table->timestamps();
        });

        // Tasks - task management for agents
        Schema::create('tasks', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('title');
            $table->text('description')->nullable();
            $table->string('assigned_agent');
            $table->string('status')->default('pending'); // pending, in_progress, completed, failed
            $table->string('priority')->default('medium'); // low, medium, high
            $table->uuid('parent_task_id')->nullable();
            $table->json('result')->nullable();
            $table->timestamp('started_at')->nullable();
            $table->timestamp('completed_at')->nullable();
            $table->timestamps();
        });

        // Agent logs - activity tracking for agents
        Schema::create('agent_logs', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('agent_name');
            $table->string('action');
            $table->text('input')->nullable();
            $table->text('output')->nullable();
            $table->string('status')->default('success'); // success, error, warning
            $table->integer('duration_ms')->default(0);
            $table->timestamps();
        });

        // Commands - command history from command center
        Schema::create('commands', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->text('command');
            $table->json('parsed_intent')->nullable();
            $table->json('assigned_agents')->nullable();
            $table->string('status')->default('processing'); // processing, completed, failed
            $table->json('result')->nullable();
            $table->timestamp('completed_at')->nullable();
            $table->timestamps();
        });

        // Automations - automation rules
        Schema::create('automations', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('name');
            $table->string('trigger_type'); // schedule, event, condition
            $table->json('trigger_config')->nullable();
            $table->string('action_type'); // agent_task, notification, api_call
            $table->json('action_config')->nullable();
            $table->boolean('is_active')->default(true);
            $table->integer('run_count')->default(0);
            $table->timestamp('last_run_at')->nullable();
            $table->timestamps();
        });

        // Tool connections - external tool integrations
        Schema::create('tool_connections', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('tool_id');
            $table->json('config')->nullable();
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });

        // AI Configuration - provider settings
        Schema::create('ai_config', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('provider'); // openai, gemini, claude
            $table->text('api_key');
            $table->string('model');
            $table->boolean('is_active')->default(false);
            $table->timestamps();
        });

        // AI Chat History - conversation logs with AI
        Schema::create('ai_chat_history', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('agent_name')->default('general');
            $table->string('role'); // user, assistant, system
            $table->longText('content');
            $table->string('provider')->nullable();
            $table->string('model')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('ai_chat_history');
        Schema::dropIfExists('ai_config');
        Schema::dropIfExists('tool_connections');
        Schema::dropIfExists('automations');
        Schema::dropIfExists('commands');
        Schema::dropIfExists('agent_logs');
        Schema::dropIfExists('tasks');
        Schema::dropIfExists('knowledge');
        Schema::dropIfExists('memory');
    }
};
