<?php

namespace App\Services;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class RouterAI
{
    private array $intentPatterns;

    public function __construct()
    {
        $this->intentPatterns = [
            'coding' => [
                'keywords' => ['code', 'কোড', 'develop', 'ডেভেলপ', 'build', 'বানাও', 'feature', 'ফিচার', 'bug', 'বাগ',
                    'fix', 'ফিক্স', 'api', 'database', 'ডাটাবেস', 'frontend', 'backend', 'deploy', 'ডিপ্লয়',
                    'module', 'মডিউল', 'upgrade', 'আপগ্রেড', 'implement', 'program', 'প্রোগ্রাম', 'software',
                    'app', 'অ্যাপ', 'website', 'ওয়েবসাইট', 'function', 'ফাংশন'],
                'agent' => 'coding',
                'priority' => 'high',
            ],
            'research' => [
                'keywords' => ['research', 'গবেষণা', 'find', 'খুঁজো', 'analyze', 'বিশ্লেষণ', 'compare', 'তুলনা',
                    'study', 'investigate', 'অনুসন্ধান', 'trend', 'ট্রেন্ড', 'market', 'মার্কেট',
                    'competitor', 'প্রতিযোগী', 'data', 'ডাটা', 'information', 'তথ্য'],
                'agent' => 'research',
                'priority' => 'medium',
            ],
            'accounting' => [
                'keywords' => ['account', 'হিসাব', 'finance', 'অর্থ', 'invoice', 'ইনভয়েস', 'payment', 'পেমেন্ট',
                    'expense', 'খরচ', 'revenue', 'আয়', 'budget', 'বাজেট', 'tax', 'ট্যাক্স', 'profit',
                    'লাভ', 'balance', 'ব্যালেন্স', 'salary', 'বেতন', 'bill', 'বিল'],
                'agent' => 'accounting',
                'priority' => 'medium',
            ],
            'marketing' => [
                'keywords' => ['marketing', 'মার্কেটিং', 'campaign', 'ক্যাম্পেইন', 'social media', 'সোশ্যাল মিডিয়া',
                    'brand', 'ব্র্যান্ড', 'advertisement', 'বিজ্ঞাপন', 'seo', 'promotion', 'প্রমোশন',
                    'audience', 'অডিয়েন্স', 'growth', 'গ্রোথ', 'ads', 'অ্যাডস'],
                'agent' => 'marketing',
                'priority' => 'medium',
            ],
            'security' => [
                'keywords' => ['security', 'সিকিউরিটি', 'audit', 'অডিট', 'vulnerability', 'দুর্বলতা', 'hack', 'হ্যাক',
                    'protect', 'সুরক্ষা', 'encrypt', 'এনক্রিপ্ট', 'firewall', 'ssl', 'auth',
                    'password', 'পাসওয়ার্ড', 'backup', 'ব্যাকআপ', 'threat', 'হুমকি'],
                'agent' => 'security',
                'priority' => 'high',
            ],
            'content' => [
                'keywords' => ['write', 'লেখো', 'article', 'আর্টিকেল', 'blog', 'ব্লগ', 'copy', 'কপি', 'draft',
                    'ড্রাফট', 'email', 'ইমেইল', 'document', 'ডকুমেন্ট', 'report', 'রিপোর্ট',
                    'proposal', 'প্রস্তাব', 'description', 'বিবরণ', 'text', 'টেক্সট'],
                'agent' => 'content',
                'priority' => 'low',
            ],
            'data_analysis' => [
                'keywords' => ['data analysis', 'ডাটা অ্যানালাইসিস', 'ডাটা বিশ্লেষণ', 'chart', 'চার্ট', 'graph', 'গ্রাফ',
                    'statistics', 'পরিসংখ্যান', 'visualization', 'ভিজুয়ালাইজেশন', 'pattern', 'প্যাটার্ন',
                    'metric', 'মেট্রিক', 'analytics', 'অ্যানালিটিক্স', 'kpi', 'performance', 'পারফরম্যান্স'],
                'agent' => 'data_analysis',
                'priority' => 'medium',
            ],
        ];
    }

    public function parseCommand(string $commandText): array
    {
        $normalizedText = mb_strtolower($commandText);
        $matchedAgents = [];
        $intents = [];

        foreach ($this->intentPatterns as $intentName => $config) {
            $matchedKeywords = array_filter($config['keywords'], function ($keyword) use ($normalizedText) {
                return str_contains($normalizedText, mb_strtolower($keyword));
            });

            if (count($matchedKeywords) > 0) {
                $matchedAgents[] = [
                    'agent' => $config['agent'],
                    'confidence' => min(count($matchedKeywords) / 3, 1.0),
                    'matchedKeywords' => array_values($matchedKeywords),
                    'priority' => $config['priority'],
                ];
                $intents[] = $intentName;
            }
        }

        // Sort by confidence descending
        usort($matchedAgents, fn($a, $b) => $b['confidence'] <=> $a['confidence']);

        // Default to research agent if no match
        if (empty($matchedAgents)) {
            $matchedAgents[] = [
                'agent' => 'research',
                'confidence' => 0.3,
                'matchedKeywords' => [],
                'priority' => 'low',
            ];
            $intents[] = 'general';
        }

        return [
            'originalCommand' => $commandText,
            'intents' => $intents,
            'assignedAgents' => $matchedAgents,
            'primaryAgent' => $matchedAgents[0]['agent'],
            'timestamp' => now()->toISOString(),
        ];
    }

    public function routeCommand(string $commandText): array
    {
        $parsed = $this->parseCommand($commandText);
        $commandId = (string) Str::uuid();

        // Store command
        DB::table('commands')->insert([
            'id' => $commandId,
            'command' => $commandText,
            'parsed_intent' => json_encode($parsed['intents']),
            'assigned_agents' => json_encode(array_map(fn($a) => $a['agent'], $parsed['assignedAgents'])),
            'status' => 'processing',
            'created_at' => now(),
        ]);

        // Create tasks for each agent
        $tasks = [];
        foreach ($parsed['assignedAgents'] as $agentInfo) {
            $taskId = (string) Str::uuid();
            $task = [
                'id' => $taskId,
                'title' => '[' . strtoupper($agentInfo['agent']) . '] ' . mb_substr($commandText, 0, 100),
                'description' => $commandText,
                'assigned_agent' => $agentInfo['agent'],
                'status' => 'pending',
                'priority' => $agentInfo['priority'],
                'parent_task_id' => $commandId,
            ];

            DB::table('tasks')->insert(array_merge($task, ['created_at' => now()]));
            $tasks[] = $task;
        }

        return [
            'commandId' => $commandId,
            'parsed' => $parsed,
            'tasks' => $tasks,
            'message' => "কমান্ড বিশ্লেষণ সম্পন্ন। " . count($parsed['assignedAgents']) . "টি এজেন্ট কাজে নিয়োজিত।",
        ];
    }

    public function getHistory(int $limit = 20): array
    {
        return DB::table('commands')
            ->orderByDesc('created_at')
            ->limit($limit)
            ->get()
            ->toArray();
    }
}
