<?php

namespace App\Services;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;

class AIProvider
{
    private static ?AIProvider $instance = null;
    private ?string $activeProviderName = null;
    private ?string $apiKey = null;
    private ?string $model = null;

    private function __construct()
    {
        $this->initFromConfig();
    }

    public static function getInstance(): self
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function initFromConfig(): void
    {
        try {
            $config = DB::table('ai_config')->where('is_active', true)->first();
            if ($config) {
                $this->activeProviderName = $config->provider;
                $this->apiKey = $config->api_key;
                $this->model = $config->model;
            }
        } catch (\Exception $e) {
            // Config table may not exist yet
        }
    }

    public function setProvider(string $provider, string $apiKey, string $model): bool
    {
        $validProviders = ['openai', 'gemini', 'claude'];
        if (!in_array($provider, $validProviders)) {
            throw new \Exception("Unknown provider: {$provider}");
        }

        $this->activeProviderName = $provider;
        $this->apiKey = $apiKey;
        $this->model = $model;

        return true;
    }

    public function isReady(): bool
    {
        return $this->activeProviderName !== null && $this->apiKey !== null;
    }

    public function getActiveProviderName(): ?string
    {
        return $this->activeProviderName;
    }

    public function reset(): void
    {
        $this->activeProviderName = null;
        $this->apiKey = null;
        $this->model = null;
    }

    public function chat(string $systemPrompt, string $userMessage, array $options = []): array
    {
        if (!$this->isReady()) {
            return [
                'success' => false,
                'error' => 'AI প্রোভাইডার কনফিগার করা হয়নি।',
                'fallback' => true,
            ];
        }

        try {
            $response = match ($this->activeProviderName) {
                'openai' => $this->chatOpenAI($systemPrompt, $userMessage, $options),
                'gemini' => $this->chatGemini($systemPrompt, $userMessage, $options),
                'claude' => $this->chatClaude($systemPrompt, $userMessage, $options),
                default => throw new \Exception("Unknown provider: {$this->activeProviderName}"),
            };

            return [
                'success' => true,
                'content' => $response,
                'provider' => $this->activeProviderName,
                'model' => $this->model,
            ];
        } catch (\Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage(),
                'fallback' => true,
            ];
        }
    }

    private function chatOpenAI(string $systemPrompt, string $userMessage, array $options = []): string
    {
        $response = Http::withHeaders([
            'Authorization' => "Bearer {$this->apiKey}",
            'Content-Type' => 'application/json',
        ])->post('https://api.openai.com/v1/chat/completions', [
            'model' => $this->model,
            'messages' => [
                ['role' => 'system', 'content' => $systemPrompt],
                ['role' => 'user', 'content' => $userMessage],
            ],
            'temperature' => $options['temperature'] ?? 0.7,
            'max_tokens' => $options['maxTokens'] ?? 2000,
        ]);

        if ($response->failed()) {
            throw new \Exception('OpenAI API error: ' . $response->body());
        }

        return $response->json('choices.0.message.content');
    }

    private function chatGemini(string $systemPrompt, string $userMessage, array $options = []): string
    {
        $url = "https://generativelanguage.googleapis.com/v1beta/models/{$this->model}:generateContent?key={$this->apiKey}";

        $response = Http::withHeaders([
            'Content-Type' => 'application/json',
        ])->post($url, [
            'system_instruction' => [
                'parts' => [['text' => $systemPrompt]],
            ],
            'contents' => [
                ['parts' => [['text' => $userMessage]]],
            ],
            'generationConfig' => [
                'temperature' => $options['temperature'] ?? 0.7,
                'maxOutputTokens' => $options['maxTokens'] ?? 2000,
            ],
        ]);

        if ($response->failed()) {
            throw new \Exception('Gemini API error: ' . $response->body());
        }

        return $response->json('candidates.0.content.parts.0.text');
    }

    private function chatClaude(string $systemPrompt, string $userMessage, array $options = []): string
    {
        $response = Http::withHeaders([
            'x-api-key' => $this->apiKey,
            'Content-Type' => 'application/json',
            'anthropic-version' => '2023-06-01',
        ])->post('https://api.anthropic.com/v1/messages', [
            'model' => $this->model,
            'max_tokens' => $options['maxTokens'] ?? 2000,
            'system' => $systemPrompt,
            'messages' => [
                ['role' => 'user', 'content' => $userMessage],
            ],
        ]);

        if ($response->failed()) {
            throw new \Exception('Claude API error: ' . $response->body());
        }

        return $response->json('content.0.text');
    }

    public function getAvailableProviders(): array
    {
        return [
            [
                'id' => 'openai',
                'name' => 'OpenAI',
                'icon' => '🟢',
                'models' => ['gpt-4o', 'gpt-4o-mini', 'gpt-4-turbo', 'gpt-3.5-turbo'],
                'description' => 'GPT-4o - সবচেয়ে শক্তিশালী',
                'pricing' => 'Pay per token',
                'apiKeyUrl' => 'https://platform.openai.com/api-keys',
                'recommended' => true,
            ],
            [
                'id' => 'gemini',
                'name' => 'Google Gemini',
                'icon' => '🔵',
                'models' => ['gemini-1.5-pro', 'gemini-1.5-flash', 'gemini-pro'],
                'description' => 'Gemini - দ্রুত ও ফ্রি!',
                'pricing' => 'Free tier available',
                'apiKeyUrl' => 'https://aistudio.google.com/apikey',
                'recommended' => false,
            ],
            [
                'id' => 'claude',
                'name' => 'Anthropic Claude',
                'icon' => '🟣',
                'models' => ['claude-sonnet-4-20250514', 'claude-3-5-haiku-20241022', 'claude-3-opus-20240229'],
                'description' => 'Claude - নিরাপদ ও বুদ্ধিমান',
                'pricing' => 'Pay per token',
                'apiKeyUrl' => 'https://console.anthropic.com/settings/keys',
                'recommended' => false,
            ],
        ];
    }
}
