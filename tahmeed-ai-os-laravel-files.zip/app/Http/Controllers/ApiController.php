<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\RouterAI;
use App\Services\AgentService;
use App\Services\AIProvider;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class ApiController extends Controller
{
    protected $routerAI;
    protected $agentService;
    protected $aiProvider;

    public function __construct()
    {
        $this->routerAI = new RouterAI();
        $this->agentService = new AgentService();
        $this->aiProvider = AIProvider::getInstance();
    }

    // =============================================
    // Dashboard
    // =============================================
    public function dashboard()
    {
        return response()->json([
            'system' => [
                'name' => 'Tahmeed AI OS',
                'version' => '1.0.0',
                'status' => 'online',
                'uptime' => now()->diffInSeconds(now()->subMinutes(rand(10, 1000))),
            ],
            'agents' => $this->agentService->getAllAgentsInfo(),
            'tasks' => [
                'total' => DB::table('tasks')->count(),
                'pending' => DB::table('tasks')->where('status', 'pending')->count(),
                'completed' => DB::table('tasks')->where('status', 'completed')->count(),
                'inProgress' => DB::table('tasks')->where('status', 'in_progress')->count(),
            ],
            'memory' => [
                'total' => DB::table('memory')->count(),
            ],
            'knowledge' => [
                'total' => DB::table('knowledge')->count(),
            ],
            'automation' => [
                'total' => DB::table('automations')->count(),
                'active' => DB::table('automations')->where('is_active', true)->count(),
            ],
            'tools' => [
                'total' => DB::table('tool_connections')->count(),
            ],
            'recentCommands' => DB::table('commands')->orderByDesc('created_at')->limit(5)->get(),
        ]);
    }

    // =============================================
    // Command Center
    // =============================================
    public function executeCommand(Request $request)
    {
        $command = $request->input('command');
        if (!$command) {
            return response()->json(['error' => 'কমান্ড প্রদান করুন'], 400);
        }

        try {
            $routing = $this->routerAI->routeCommand($command);
            $results = $this->agentService->executeMultipleTasks($routing['tasks']);

            // Store conversation in memory
            DB::table('memory')->insert([
                'id' => Str::uuid(),
                'type' => 'conversation',
                'content' => $command,
                'context' => json_encode($results),
                'importance' => 'medium',
                'created_at' => now(),
            ]);

            // Update command status
            DB::table('commands')->where('id', $routing['commandId'])->update([
                'status' => 'completed',
                'result' => json_encode($results),
                'completed_at' => now(),
            ]);

            $successCount = collect($results)->where('status', 'fulfilled')->count();

            return response()->json([
                'success' => true,
                'commandId' => $routing['commandId'],
                'routing' => $routing['parsed'],
                'results' => collect($results)->map(function ($r) {
                    return [
                        'agent' => $r['task']['assigned_agent'] ?? null,
                        'status' => $r['status'],
                        'result' => $r['result'] ?? null,
                        'error' => $r['error'] ?? null,
                    ];
                })->toArray(),
                'message' => "✅ কমান্ড সম্পন্ন! {$successCount}/" . count($results) . " এজেন্ট সফল।",
            ]);
        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    public function commandHistory(Request $request)
    {
        $limit = $request->input('limit', 20);
        return response()->json(
            DB::table('commands')->orderByDesc('created_at')->limit($limit)->get()
        );
    }

    // =============================================
    // Agents
    // =============================================
    public function getAgents()
    {
        return response()->json($this->agentService->getAllAgentsInfo());
    }

    public function getAgentStats()
    {
        return response()->json($this->agentService->getStats());
    }

    // =============================================
    // Tasks
    // =============================================
    public function getTasks(Request $request)
    {
        $status = $request->input('status');
        $query = DB::table('tasks')->orderByDesc('created_at')->limit(50);

        if ($status) {
            $query->where('status', $status);
        }

        return response()->json($query->get());
    }

    public function getTasksSummary()
    {
        return response()->json([
            'total' => DB::table('tasks')->count(),
            'pending' => DB::table('tasks')->where('status', 'pending')->count(),
            'inProgress' => DB::table('tasks')->where('status', 'in_progress')->count(),
            'completed' => DB::table('tasks')->where('status', 'completed')->count(),
            'failed' => DB::table('tasks')->where('status', 'failed')->count(),
        ]);
    }

    // =============================================
    // Memory
    // =============================================
    public function getMemory(Request $request)
    {
        $type = $request->input('type');
        $query = DB::table('memory')->orderByDesc('created_at');

        if ($type) {
            $query->where('type', $type);
        }

        return response()->json($query->get());
    }

    public function storeMemory(Request $request)
    {
        $type = $request->input('type');
        $content = $request->input('content');

        if (!$type || !$content) {
            return response()->json(['error' => 'type ও content আবশ্যক'], 400);
        }

        $id = Str::uuid();
        DB::table('memory')->insert([
            'id' => $id,
            'type' => $type,
            'content' => $content,
            'context' => $request->input('context'),
            'tags' => $request->input('tags') ? json_encode($request->input('tags')) : null,
            'importance' => $request->input('importance', 'medium'),
            'created_at' => now(),
        ]);

        return response()->json(['id' => $id]);
    }

    public function searchMemory(Request $request)
    {
        $query = $request->input('q', '');
        return response()->json(
            DB::table('memory')->where('content', 'LIKE', "%{$query}%")->get()
        );
    }

    public function getMemoryStats()
    {
        return response()->json([
            'total' => DB::table('memory')->count(),
            'byType' => DB::table('memory')->select('type', DB::raw('COUNT(*) as count'))->groupBy('type')->get(),
        ]);
    }

    public function deleteMemory($id)
    {
        DB::table('memory')->where('id', $id)->delete();
        return response()->json(['success' => true]);
    }

    // =============================================
    // Knowledge
    // =============================================
    public function getKnowledge(Request $request)
    {
        $type = $request->input('type');
        $query = DB::table('knowledge')->orderByDesc('created_at');

        if ($type) {
            $query->where('type', $type);
        }

        return response()->json($query->get());
    }

    public function storeKnowledge(Request $request)
    {
        $title = $request->input('title');
        $type = $request->input('type');

        if (!$title || !$type) {
            return response()->json(['error' => 'title ও type আবশ্যক'], 400);
        }

        $id = Str::uuid();
        DB::table('knowledge')->insert([
            'id' => $id,
            'title' => $title,
            'type' => $type,
            'content' => $request->input('content'),
            'metadata' => $request->input('metadata') ? json_encode($request->input('metadata')) : null,
            'tags' => $request->input('tags') ? json_encode($request->input('tags')) : null,
            'created_at' => now(),
        ]);

        return response()->json(['id' => $id]);
    }

    public function searchKnowledge(Request $request)
    {
        $query = $request->input('q', '');
        return response()->json(
            DB::table('knowledge')
                ->where('title', 'LIKE', "%{$query}%")
                ->orWhere('content', 'LIKE', "%{$query}%")
                ->get()
        );
    }

    public function deleteKnowledge($id)
    {
        DB::table('knowledge')->where('id', $id)->delete();
        return response()->json(['success' => true]);
    }

    // =============================================
    // Automations
    // =============================================
    public function getAutomations()
    {
        return response()->json(DB::table('automations')->get());
    }

    public function toggleAutomation($id)
    {
        $automation = DB::table('automations')->where('id', $id)->first();
        if (!$automation) {
            return response()->json(['error' => 'Not found'], 404);
        }

        DB::table('automations')->where('id', $id)->update([
            'is_active' => !$automation->is_active,
            'updated_at' => now(),
        ]);

        return response()->json([
            'success' => true,
            'is_active' => !$automation->is_active,
        ]);
    }

    public function getAutomationStatus()
    {
        return response()->json([
            'total' => DB::table('automations')->count(),
            'active' => DB::table('automations')->where('is_active', true)->count(),
            'inactive' => DB::table('automations')->where('is_active', false)->count(),
        ]);
    }

    // =============================================
    // Tools
    // =============================================
    public function getTools(Request $request)
    {
        $category = $request->input('category');

        $tools = [
            ['id' => 'calculator', 'name' => 'ক্যালকুলেটর', 'icon' => '🔢', 'description' => 'গাণিতিক হিসাব', 'category' => 'utility'],
            ['id' => 'translator', 'name' => 'অনুবাদক', 'icon' => '🌐', 'description' => 'ভাষা অনুবাদ', 'category' => 'utility'],
            ['id' => 'file_manager', 'name' => 'ফাইল ম্যানেজার', 'icon' => '📁', 'description' => 'ফাইল অপারেশন', 'category' => 'system'],
            ['id' => 'scheduler', 'name' => 'শিডিউলার', 'icon' => '📅', 'description' => 'টাস্ক শিডিউলিং', 'category' => 'automation'],
            ['id' => 'notifier', 'name' => 'নোটিফায়ার', 'icon' => '🔔', 'description' => 'নোটিফিকেশন পাঠানো', 'category' => 'communication'],
            ['id' => 'api_tester', 'name' => 'API টেস্টার', 'icon' => '🔌', 'description' => 'API এন্ডপয়েন্ট টেস্ট', 'category' => 'development'],
            ['id' => 'code_formatter', 'name' => 'কোড ফরম্যাটার', 'icon' => '✨', 'description' => 'কোড ফরম্যাটিং', 'category' => 'development'],
            ['id' => 'json_viewer', 'name' => 'JSON ভিউয়ার', 'icon' => '📋', 'description' => 'JSON ডাটা পার্সিং', 'category' => 'development'],
        ];

        if ($category) {
            $tools = array_filter($tools, fn($t) => $t['category'] === $category);
        }

        return response()->json(array_values($tools));
    }

    public function connectTool(Request $request)
    {
        $toolId = $request->input('toolId');
        $config = $request->input('config', []);

        $id = Str::uuid();
        DB::table('tool_connections')->insert([
            'id' => $id,
            'tool_id' => $toolId,
            'config' => json_encode($config),
            'is_active' => true,
            'created_at' => now(),
        ]);

        return response()->json(['success' => true, 'id' => $id]);
    }

    public function getToolConnections()
    {
        return response()->json(DB::table('tool_connections')->get());
    }

    // =============================================
    // AI Routes
    // =============================================
    public function aiStatus()
    {
        $config = DB::table('ai_config')->where('is_active', true)->first();

        return response()->json([
            'configured' => $this->aiProvider->isReady(),
            'activeProvider' => $this->aiProvider->getActiveProviderName(),
            'config' => $config ? [
                'provider' => $config->provider,
                'model' => $config->model,
                'is_active' => $config->is_active,
                'updated_at' => $config->updated_at ?? $config->created_at,
            ] : null,
            'message' => $this->aiProvider->isReady()
                ? '✅ AI সক্রিয় - ' . $this->aiProvider->getActiveProviderName()
                : '⚠️ AI কনফিগার করা হয়নি',
        ]);
    }

    public function aiProviders()
    {
        return response()->json($this->aiProvider->getAvailableProviders());
    }

    public function aiConfigure(Request $request)
    {
        $provider = $request->input('provider');
        $apiKey = $request->input('apiKey');
        $model = $request->input('model');

        if (!$provider || !$apiKey || !$model) {
            return response()->json(['error' => 'provider, apiKey, model আবশ্যক'], 400);
        }

        try {
            DB::table('ai_config')->update(['is_active' => false]);

            DB::table('ai_config')->insert([
                'id' => Str::uuid(),
                'provider' => $provider,
                'api_key' => $apiKey,
                'model' => $model,
                'is_active' => true,
                'created_at' => now(),
            ]);

            $this->aiProvider->setProvider($provider, $apiKey, $model);

            return response()->json([
                'success' => true,
                'message' => "✅ {$provider} কনফিগার সম্পন্ন! Model: {$model}",
            ]);
        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    public function aiTest()
    {
        if (!$this->aiProvider->isReady()) {
            return response()->json(['success' => false, 'error' => 'AI কনফিগার করা হয়নি'], 400);
        }

        $response = $this->aiProvider->chat(
            'তুমি একটি AI assistant।',
            'তুমি কে? এক লাইনে বলো।',
            ['maxTokens' => 100]
        );

        if ($response['success']) {
            return response()->json([
                'success' => true,
                'message' => '✅ AI সংযোগ সফল!',
                'response' => $response['content'],
                'provider' => $response['provider'],
                'model' => $response['model'],
            ]);
        }

        return response()->json(['success' => false, 'error' => $response['error']]);
    }

    public function aiChat(Request $request)
    {
        $message = $request->input('message');
        $agent = $request->input('agent');

        if (!$message) {
            return response()->json(['error' => 'message আবশ্যক'], 400);
        }

        if (!$this->aiProvider->isReady()) {
            return response()->json(['success' => false, 'error' => 'AI কনফিগার করা হয়নি'], 400);
        }

        $systemPrompt = $agent
            ? ($this->agentService->getAgentPrompt($agent) ?? 'তুমি Tahmeed AI OS-এর সহকারী।')
            : 'তুমি Tahmeed AI OS-এর সহকারী।';

        $response = $this->aiProvider->chat($systemPrompt, $message);

        if ($response['success']) {
            DB::table('ai_chat_history')->insert([
                'id' => Str::uuid(),
                'agent_name' => $agent ?? 'general',
                'role' => 'assistant',
                'content' => $response['content'],
                'provider' => $response['provider'],
                'model' => $response['model'],
                'created_at' => now(),
            ]);

            return response()->json([
                'success' => true,
                'response' => $response['content'],
                'provider' => $response['provider'],
                'model' => $response['model'],
            ]);
        }

        return response()->json(['success' => false, 'error' => $response['error']]);
    }

    public function aiDisable()
    {
        DB::table('ai_config')->update(['is_active' => false]);
        $this->aiProvider->reset();
        return response()->json(['success' => true, 'message' => 'AI নিষ্ক্রিয় করা হয়েছে']);
    }

    public function aiUsage()
    {
        try {
            return response()->json([
                'totalMessages' => DB::table('ai_chat_history')->count(),
                'byAgent' => DB::table('ai_chat_history')
                    ->select('agent_name', DB::raw('COUNT(*) as count'))
                    ->groupBy('agent_name')
                    ->get(),
            ]);
        } catch (\Exception $e) {
            return response()->json(['totalMessages' => 0, 'byAgent' => []]);
        }
    }
}
